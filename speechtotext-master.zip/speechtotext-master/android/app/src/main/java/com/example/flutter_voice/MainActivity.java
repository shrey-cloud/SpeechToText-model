package com.example.flutter_voice;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
